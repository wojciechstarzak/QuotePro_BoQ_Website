1.You need to go here http://www.dnngo.net and register.

2. Please install the module in DNN and add it in a page. Then click the License link to abtain the Machine Key.

3. You can send one email to dnnskindev@gmail.com and tell us your Invoice ID, Machine Key and Username. After that, we will generate one piece of license information. If your site is a demo site, the license is still valid when you transfer your demo site to your live site.

4. You can go here http://www.dnngo.net/MyAccount/OnlineAuthorization.aspx and manage your license information.

5.Our site is a good place to advertise for your site. After you purchase our product and use it on your site, we can add your logo and link address on our product sale page and demo site. Then it will help your site to increase audience and it also be helpful for our clients to see how our modules run on your site. This is a win-win result. If you're interested in this, please send an e-mail to dnnskindev@gmail.com to discuss with us.

If you're satisfied with our product and support, you can give us a good comment and rating on snowcovered. Any question, please e-mail us and we will give you the best support. Thank you.





Free Download Link:
http://www.dnngo.net/FreeDownloads/tabid/184/Token/ViewInfo/ItemID/201/Default.aspx

Documentation:
http://www.dnngo.net/doc/DNNGo_DNNGallery_V4/index.html#Effect_25_ResponsiveSlide


Buy link:
http://store.dotnetnuke.com/home/product-details/dnngo-weather-slider-203-effect17-by-dnngallery-weather-slider-dynamic-weather-slide-weather/r/cd57d7207c9d4266bc34/